package edu.ncsu.monopoly.gui;

import edu.ncsu.monopoly.IOwnableCell;

public interface CellInfoFormatter {
    public String format(IOwnableCell cell);
}
